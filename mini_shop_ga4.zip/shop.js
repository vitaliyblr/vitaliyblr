var shop = (function(){
  var STORAGE = 'mini_shop_cart_v1';
  function load(){ try{ return JSON.parse(localStorage.getItem(STORAGE)||'[]'); }catch(e){return []} }
  function save(cart){ localStorage.setItem(STORAGE, JSON.stringify(cart)); }
  function getCart(){ return load(); }
  function cartCount(){ return load().reduce(function(s,i){return s+i.qty;},0); }
  function addToCart(item){
    var cart = load();
    var found = cart.find(function(it){ return it.id === item.id; });
    if(found){ found.qty += 1; } else { cart.push({id:item.id,name:item.name,price:item.price,qty:1}); }
    save(cart);
  }
  function clearCart(){ save([]); }
  return { getCart:getCart, addToCart:addToCart, clearCart:clearCart, cartCount:cartCount };
})();